# Tahsin_App_Skripsi

Aplikasi untuk deteksi Kesalahan baca Alquran dengan Algoritma Lev.Distance dan Google Speech API.

-aplikasi Skripsi-