package com.example.galang.tahsin_beta_kotlin.Model

class Kesalahan(
        val jenis: String,
        val teks: String,
        val hurufAwal : Int,
        val hurufAkhir : Int
)